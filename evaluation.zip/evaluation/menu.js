

var count=0;
var arr=[];
var url = "https://www.themealdb.com/api/json/v1/1/categories.php";
//var url = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=1";
async function getData(){
    try{
        let res = await fetch(url);
        let fetchedData = await res.json();
        console.log("fetchedData:" , fetchedData);
        //appendProduct(fetchedData);
        let data = fetchedData.categories;
        console.log(data);
        appendProduct(data);
    }
    catch(err){
        console.log("myError:" , err);
    }
}
getData();
// function addTocart(){
//     count++;
//     document.querySelector("#itemCount").textContent=count;
//     console.log("here");
//     window.location.href="cart.html";
// }
var s =document.querySelector("#item").innerHTML;
console.log(s);
function appendProduct(meal){
     meal.forEach(function(elem){
        let div = document.createElement("div");
        let img = document.createElement("img");
        let name=document.createElement("h1");
        let price = document.createElement("h2");
        price.textContent=Math.floor(Math.random()*(500-100)+100) +"/-";
        let button= document.createElement("button");
        button.textContent ="Add to Cart";

        img.src=elem.strCategoryThumb;
        name.textContent=elem.strCategory;

        div.id="menu-div";
        div.append(img , name ,price, button);

        document.querySelector("#container").append(div);

        button.addEventListener("click",function(){
            count++;
            document.querySelector("#item").innerHTML = `No. Of Items : ${count}`;
            arr.push(elem);
            localStorage.setItem("arr" , JSON.stringify(arr));
        });

        
    })
}


document.querySelector("#cart").addEventListener("click",function(){
    console.log("here");
    window.location.href="cart.html";
    
})

document.querySelector("#check").addEventListener("click" , function(){
    window.location.href="checkOut.html";
})





