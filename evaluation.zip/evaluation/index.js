document.querySelector("#menu").addEventListener("click" , function(){
    console.log("Hi i am menu");
    window.location.href = "menu.html"
})